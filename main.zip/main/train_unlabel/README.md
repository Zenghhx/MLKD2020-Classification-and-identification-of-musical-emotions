需要包含两个文件:  
feature.npy  
name.npy  

其中feature.npy是预处理的无标签样本特征.  
name.npy是 { 行号 : [ 片段号, 歌曲名 ] } 的对照字典