需要包含三个文件  
feature_train.npy  
label_train.npy  
name.npy  

其中feature.npy是预处理的有标签样本特征.  
label_train.npy是与feature对应的样本标签.  
name.npy是 { 行号 : [ 片段号, 歌曲名 ] } 的对照字典.